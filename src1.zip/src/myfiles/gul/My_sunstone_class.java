/**
 **/
package myfiles.gul;

public class My_sunstone_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 654876632;
		boolean status = true;
		int num = 8765;
		long distance = 765432L;
		float pi = 3.1467676f;
		float num2 = 8765432.8767654556788f;
		double num1 = 897654321345678.87875465432;
			
		System.out.println("My Number is :"+ a);
		System.out.println("Value  is :"+ pi);
		System.out.println("Value  is :"+ num);
		System.out.println("Value  is :"+ num1);
		System.out.println("Value  is :"+ num2);
		System.out.println("Value  is :"+ distance);
		System.out.println("Value  is :"+ status);

	}

}

/**

**/


/**

package myfiles.gul;
public class My_sunstone_class {

	public float Si(int principle, float roi, int time) // method
	{
		float result = ((principle * roi * time) / 100);
		return result;
	}

	public static void main(String[] args) {

		int p =2000;
		My_sunstone_class fd = new My_sunstone_class();
		// object creation and object is created inside the class main method

		float res = fd.Si(p, 4.5f, 3);
		System.out.println("Simple Interest is :" + res);

		float amount = res + p;
		System.out.println("Total Amount is :" + amount);

		}

}


**/


//Function overloading 





