package Assignment;

interface SampleA{
	int price = 120;
	String name = "Apple";
	
	void  area();
	void calculate();
	
}

interface SampleB{
	int price = 180;
	String name = "Mango";
	
	void area();
	void  display();
	
}
interface C extends SampleA, SampleB{
}
class Demo implements C{
	
	@Override
	public void display() {
		System.out.println("This is the method display ");
		
	}

	@Override
	public void area() {
		System.out.println("This is the area");
		
	}

	@Override
	public void calculate() {
		System.out.println("This is the calculation");
		
	}
}


public class Interface {

	public static void main(String[] args) {
		
		
		C ob = new Demo();
		ob.area();
		ob.calculate();
		ob.display();
		
		new Demo();
			System.out.println(SampleA.price+"-"+SampleA.name);
			System.out.println(SampleB.price+"-"+SampleB.name);
			
		

	}

}
