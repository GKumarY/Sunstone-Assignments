

/**
package Assignment;

public class My_Assign {
	
	int a=23;
	int b = 76;
	int c = a+b;
	System.out.println("The sum  of :"+ c);
	System.out.println("My Number is :"+ a);
	

}


**/

// add two numbers

/**
package Assignment;

public class My_Assign  {

    public static int add(int num1, int num2) {
        return num1 + num2;
    }

    public static void main(String[] args) {
        int N1 = 10;
        int N2 = 20;
        int sum = add(N1, N2);
        System.out.println("The sum of " + N1 + " and " + N2 + " is: " + sum);
    }
}

**/

// Area of  Circle

/**



package Assignment;

public class My_Assign  {

    public static float area(float area) {
        return area;
    }

    public static void main(String[] args) {
        int r = 10;
        float pi = 3.14f;
        float area = 2*pi*r;
        System.out.println("The Area of  Circle: " + area);
    }
}

**/

// Area of Rectangle

/**


package Assignment;

public class My_Assign  {

    public static float area(float area) {
        return area;
    }

    public static void main(String[] args) {
        float l = 10f;
        float b = 20f;
        float area = l*b;
        System.out.println("The Area of  Rectangle: " + area);
    }
}


**/


// Area of Square


/**


package Assignment;

public class My_Assign  {

    public static float area(float area) {
        return area;
    }

    public static void main(String[] args) {
        float l = 10f;
        float area = l*l;
        System.out.println("The Area of Square: " + area);
    }
}

**/