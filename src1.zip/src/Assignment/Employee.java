package Assignment;


//heirarcial Inheritance   ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/**
class Employee1{    // Parent
	
	int empid;
	String empname;
	float salary;
	
	Employee1(int empid, String empname, float salary){
		this.empid = empid;
		this.empname = empname;
		this.salary = salary;
	}
	
	public void display(){
		System.out.println(" the employee details are :" + empid +" - " + empname + "-" + salary);
	}
}

class SubEmployee extends Employee1{    // Child
	
	int bonus;
	
	SubEmployee(int empid, String empname, float salary,int bonus){
		super(empid,empname,salary);
		this.bonus = bonus;
	}
	
	public void calculate(){
		float final_sal = salary + (bonus * salary)/100;
		System.out.println(" the final salary after adding the bonus is " + final_sal);
	}
	
}

public class Employee {

	public static void main(String[] args) {
	
		SubEmployee sb = new SubEmployee(101, "Ravi", 34000.00f, 20);
        sb.display();
        sb.calculate();
	}
}



**/

//Multilevel Inheritance   ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

/**

class Employee1{    // Parent
	
	int empid;
	String empname;
	float salary;
	
	Employee1(int empid, String empname, float salary){
		this.empid = empid;
		this.empname = empname;
		this.salary = salary;
	}
	
	public void display(){
		System.out.println(" the employee details are :" + empid +" - " + empname + "-" + salary);
	}
}

class SubEmployee extends Employee1{    // Child
	
	int bonus;
	
	SubEmployee(int empid, String empname, float salary,int bonus){
		super(empid,empname,salary);
		this.bonus = bonus;
	}
	
	public void calculate(){
		float final_sal = salary + (bonus * salary)/100;
		System.out.println(" the final salary after adding the bonus is " + final_sal);
	}
	
}

class TempEmployee extends SubEmployee{
	
    int duration;
	
	TempEmployee(int empid, String empname, float salary,int bonus,int duration){
		super(empid,empname,salary,bonus);
		this.duration = duration;
	}
	
	public void durationEmployee(){
		System.out.println(" The employeee duration is " + duration);
	}
	
}

public class Employee {

	public static void main(String[] args) {
	
		TempEmployee sb = new TempEmployee(101, "Ravi", 34000.00f, 20,3);
        sb.display();
        sb.calculate();
        sb.durationEmployee();
	}
}

**/



// Hybrid Inheritance +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


/**


class Employee1{    // Parent
	
	int empid;
	String empname;
	float salary;
	
	Employee1(int empid, String empname, float salary){
		this.empid = empid;
		this.empname = empname;
		this.salary = salary;
	}
	
	public void display(){
		System.out.println(" the employee details are :" + empid +" - " + empname + "-" + salary);
	}
}

class SubEmployee extends Employee1{    // Child
	
	int bonus;
	
	SubEmployee(int empid, String empname, float salary,int bonus){
		super(empid,empname,salary);
		this.bonus = bonus;
	}
	
	public void calculate(){
		float final_sal = salary + (bonus * salary)/100;
		System.out.println(" the final salary after adding the bonus is " + final_sal);
	}
	
}

class TempEmployee extends SubEmployee{
	
    int duration;
	
	TempEmployee(int empid, String empname, float salary,int bonus,int duration){
		super(empid,empname,salary,bonus);
		this.duration = duration;
	}
	
	public void durationEmployee(){
		System.out.println(" The employeee duration is " + duration);
	}
	
}

class PermanentEmployee extends SubEmployee{
	
    int duration;
	
    PermanentEmployee(int empid, String empname, float salary,int bonus,int duration){
		super(empid,empname,salary,bonus);
		this.duration = duration;
	}
	
	public void durationEmployee(){
		System.out.println(" The employeee duration is " + duration);
	}
}

public class Employee {

	public static void main(String[] args) {
	
		TempEmployee sb = new TempEmployee(101, "Ravi", 34000.00f, 20,3);
        sb.display();
        sb.calculate();
        sb.durationEmployee();
        
        PermanentEmployee sb1 = new PermanentEmployee(102, "Kirti", 40000.00f, 30,5);
        sb1.display();
        sb1.calculate();
        sb1.durationEmployee();
	}
}

 */

// 
