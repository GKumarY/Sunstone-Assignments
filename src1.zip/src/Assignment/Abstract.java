package Assignment;

/**
abstract class Customer{
	Customer(){
		System.out.println("This is the constructor of the customer");
		
		
	}
	public void details() {
		System.out.println("This is non-abstract method  of the customer");
		
	}
	abstract public void purchase();
	abstract public void sell();
	abstract public void leaves();
	
}

abstract class Employee1 extends Customer{
	abstract public void purchase();
	abstract public void sell();
	
}

abstract class Retailer extends Customer{
	abstract public void purchase();
	
	
	public void sell();{
		System.out.println("Retailer is going to sell the product")
	}
}
	
class Person extends Retailer() {
	
	public void purchase();{
		System.out.println("Retailer is going to Purchase the product")
		}
	
}

class Sample extends Employee1{

	@Override
	public void purchase() {
		System.out.println("Method 1 ");
		
	}

	@Override
	public void sell() {
		System.out.println("Method 2");
		
	}

	@Override
	public void leaves() {
		System.out.println("Method 3");
		
	}
}



public class Abstract {

	public static void main(String[] args) {
		
		Customer cust = new Person();
		cust.sell();
		cust.purchase();
		cust.details();
		
		
		Customer c1 = new Sample();
		c1.sell();
		c1.purchase();
		c1.leaves();
		
		// TODO Auto-generated method stub

	}

}


**/



/**
abstract class Customer{
	
	Customer(){
		System.out.println("This is the constructor of the Customer");
	}
	
	public void details(){
		System.out.println("This is non-abstract method of the customer class");
	}
	
	abstract public void purchase();
	abstract public void sell();
}

abstract class Employee1 extends Customer{

	abstract public void purchase();
	abstract public void sell();
	abstract public void leaves();  // created in this child class
}

abstract class Retailer extends Customer{
	
	abstract public void purchase();
	
	public void sell(){
		System.out.println("Reatiler is goign to sell the product");
	}
}

class Person extends Retailer{

	public void purchase() {
		System.out.println("The person  is goign to purchase the product");
	}
}

class Sample extends Employee1{

	@Override
	public void purchase() {
		System.out.println("Method 1 ");
		
	}

	@Override
	public void sell() {
		System.out.println("Method 2");
		
	}

	@Override
	public void leaves() {
		System.out.println("Method 3");
		
	}
}

public class Abstract {

	public static void main(String[] args) {
	
		Customer cust = new Person();
		cust.sell();
		cust.purchase();
		cust.details();
		
		Employee1 c1 = new Sample();
		c1.sell();
		c1.purchase();
		c1.leaves();

	}

}



**/

/**


abstract class Bike {
	
	Bike() {
		System.out.println("bike is created");
	}

	abstract void run1(); // abstract method()

	void changeGear() // non-abstract method()
	{
		System.out.println("gear changed");
	}
}

abstract class Honda extends Bike {
	
	Honda(){
		System.out.println("honda is created");
	}
	// changeGear(), run1()	
	abstract void run();	
	abstract void run1();
}
	
abstract class Hello extends Honda {
	
	void run() {
		System.out.println("running safely..");
	}
	
	abstract void run1();
	abstract void play();
}

abstract class Temp extends Hello{

	void run1() {
		System.out.println(" i am in temp class");		
	}
	abstract void play();
}

class Ground extends Temp{

	void play() {
		System.out.println(" i am playing....");		
	}
}

public class Abstract{
	public static void main(String args[]) {
		Temp k= new Ground();
		k.run();
		k.run1();
		k.changeGear();
		k.play();
	}
}
// write the main method here




**/




/**

abstract class Abstract {
	
	private String name = "abc";
	
	Abstract(){
		System.out.println("inside the abstract class..");
	}
	
	public void myMethod() {                // non-abstract method
		System.out.println("Hello  : " + name);
	}

	abstract public void anotherMethod();  // hidden method  abstract method declaration
}

public class BasicAbstractExample extends Abstract {

	BasicAbstractExample() {
		//super();
		System.out.println(" Inside child class...");
	}

	public void anotherMethod() {   //  defining the method
		System.out.println("Abstract method  : ");
	}
	
	void play(){
		System.out.println("play method");
	}
}
public class Abstract {
	public static void main(String[] args) {
		
		//AbstractDemo abs = new AbstractDemo();		
		Abstract obj = new BasicAbstractExample(); 
		
		obj.anotherMethod();
		obj.myMethod();
	}
}



**/
